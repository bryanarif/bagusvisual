package com.example.heru_hardadi_pc.mymultiuser.util;

/**
 * Created by heru_hardadi_pc on 04/08/2018.
 */

public class Server {
    public static final String URL = "http://192.168.1.6:8080/jadi/";
    public static final String URL2 = "http://192.168.1.6:8080/jadi/";
    public static final String URL1 = "http://192.168.1.6:8080/jadi/";
}
